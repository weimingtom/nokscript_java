#pragma once

#ifndef STRICT
#define STRICT
#endif
#ifndef DIRECTINPUT_VERSION
#define DIRECTINPUT_VERSION 0x0800
#endif
#include <windows.h>
#include <ddraw.h>
#include <dinput.h>
#include <dsound.h>
#include <dmusici.h>
#include <mmsystem.h>

#define SOUNDBUFFER_NUM 5

class CNkSound  
{
public:
	CNkSound();
	CNkSound(char* lpszFileName);
	virtual ~CNkSound();
	int Load(char* lpszFileName);
	int Play(DWORD dwFlags);
	int Stop();
	int Release();
private:
	LPDIRECTSOUNDBUFFER m_pdsb[SOUNDBUFFER_NUM];
	LPDIRECTSOUND m_pDS;
	int m_index;
};

