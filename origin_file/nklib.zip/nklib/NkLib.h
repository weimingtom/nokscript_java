#pragma once

#include <list>
#include <vector>
#include <algorithm>
using namespace std;

#ifndef STRICT
#define STRICT
#endif
#ifndef DIRECTINPUT_VERSION
#define DIRECTINPUT_VERSION 0x0800
#endif
#include <windows.h>
#include <ddraw.h>
#include <dinput.h>
#include <dsound.h>
#include <dmusici.h>
#include <mmsystem.h>

#define GAMETITLE "SUZURI SHOOTING VER 1.00��"
#define SCREEN_WIDTH    320
#define SCREEN_HEIGHT   240
#define SCREEN_BPP      16
#define _FPS 16.6
#define FPSSHOW_WIDTH	24
#define FPSSHOW_HEIGHT	16

#define MB(str) MessageBox(NULL,str,GAMETITLE,MB_OK)
#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete [] (p);	  (p)=NULL; } }
#define SAFE_ACQUIRE(p)  { if(p) { (p)->Acquire();	} }
#define SAFE_UNACQUIRE(p) { if(p) { (p)->Unacquire();} }

#define INP_NEUTRAL	-1
#define INP_RIGHT	0
#define INP_LEFT	1
#define INP_DOWN	2
#define INP_UP		3
#define INP_B0		4
#define INP_B1		5
#define INP_B2		6
#define INP_B3		7
#define INP_MAX		8

#define FONT_ITALIC		0x01
#define FONT_ULINE		0x02
#define FONT_LINEOUT	0x04

#define	to555(_a_) (((_a_ & _mask4) >> 1) | (_a_ & _mask5))
#define	to565(_a_) (((_a_ & _mask4) << 1) | (_a_ & _mask5))

class CNkLib;
class CNkImage;
class CDrawQue;
class CCalculate;
extern CNkLib* g_pNkLib;

int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR pCmdLine, int nCmdShow);
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

typedef struct tagDRAWINFO
{
	int spr;
	CDrawQue *pDrawQue;
	bool operator<(tagDRAWINFO rinfo)
	{ 
		return spr < rinfo.spr; 
	}
	tagDRAWINFO(){}
	tagDRAWINFO(int s,CDrawQue *que)
	{
		spr = s;
		pDrawQue = que;
	}
}DRAWINFO, *LPDRAWINFO;

class CNkLib  
{
public:
	CNkLib(HINSTANCE hInst);
	virtual ~CNkLib();
	int InitWindow(int nCmdShow);
	int InitDirectDraw(bool bWindow,bool bDouble);
	int WaitTime();
	int Flip();
	int ShowFPS();
	int Text(char *txt, int x, int y, int size, int weight, DWORD dwFlag, COLORREF color, int layer);
	int Circle(int width, COLORREF color, int left, int top, int right, int bottom, int layer);
	int PlusGamma(int red, int green, int blue);
	int UpdateBounds();
	int CreateSurface(LPDDSURFACEDESC2 lpDDSurfaceDesc2, LPDIRECTDRAWSURFACE7* lplpDDSurface);
	int BltFast(int iDestX, int iDestY, LPDIRECTDRAWSURFACE7 pdds, LPRECT prcSrc, bool trans);
	int BltStretch(LPRECT prcDest, LPDIRECTDRAWSURFACE7 pdds, LPRECT prcSrc, bool trans);
	int TextOutBase(char* text, int x, int y, int size, int weight, DWORD dwFlag, COLORREF color);
	int DrawCircle(int width, COLORREF color, int left, int top, int right, int bottom);
	int BltEffect(int iDestX, int iDestY, LPDIRECTDRAWSURFACE7 pdds, LPRECT prcSrc, CCalculate* pCal);
	int BltEffectBase(int iDestX, int iDestY, LPDIRECTDRAWSURFACE7 pdds, LPRECT prcSrc, CCalculate* pCal);
	int Blt0To0(DWORD *pDest, DWORD *pSrc, int a_skip, int b_skip, int w, int h, CCalculate* pCal);
	int Blt1To0(DWORD *pDest, DWORD *pSrc, int a_skip, int b_skip, int w, int h, CCalculate* pCal);
	int Blt0To1(DWORD *pDest, DWORD *pSrc, int a_skip, int b_skip, int w, int h, CCalculate* pCal);
	int Blt1To1(DWORD *pDest, DWORD *pSrc, int a_skip, int b_skip, int w, int h, CCalculate* pCal);
	friend LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
public:
	int	GetWindowWidth()
	{
		return SCREEN_WIDTH * (1 + (int)m_bDouble);
	}
	int	GetWindowHeight()
	{
		return SCREEN_HEIGHT * (1 + (int)m_bDouble);
	}
	int	UpdateDirectDraw()
	{
		return InitDirectDraw(m_bWindow, m_bDouble);
	}
	int	ChangeMode()
	{
		m_bWindow = !m_bWindow;
		m_bDouble = m_bWindow;
		return InitDirectDraw(m_bWindow, m_bDouble);
	}
	int	ChangeScreenMode()
	{
		m_bWindow = !m_bWindow;
		return InitDirectDraw(m_bWindow, m_bDouble);
	}
	int	ChangeScreenSize()
	{
		m_bDouble = !m_bDouble;
		return InitDirectDraw(m_bWindow, m_bDouble);
	}
	bool GetWindow()
	{
		return m_bWindow;
	}
	bool GetDouble()
	{
		return m_bDouble;
	}
	bool SetWindow(bool bWindow)
	{
		return m_bWindow = bWindow;
	}
	bool SetDouble(bool bDouble)
	{
		return m_bDouble = bDouble;
	}
	bool IsOk()
	{
		return m_pDD && m_pddsPrimaryBuffer && m_pddsPrimaryBuffer;
	}
	int InitGamma()
	{
		return m_pGammaControl->SetGammaRamp(0, &m_gammaInit);
	}
	int	SetGamma(int red,int green,int blue)
	{
		InitGamma();
		return PlusGamma(red, green, blue);
	}
	int	SetGamma(double red,double green,double blue)
	{
		return SetGamma(red * 60000, green * 60000, blue * 6000);
	}
	void AddList(CNkImage* pimg)
	{
		m_lstpImage.push_front(pimg);
	}
	void ClearList()
	{
		m_lstpImage.clear();
	}
	void RemoveList(CNkImage* pimg)
	{
		m_lstpImage.remove(pimg);
	}
	int	ReloadAllImage();
	void ReleaseAllImage();
public:
	int DrawList();
	void ClearDrawList()
	{
		m_lstDInfo.clear();
	}
	void AddDrawList(tagDRAWINFO dInfo)
	{
		m_lstDInfo.push_front(dInfo);
	}
public:
	int	InitInput();
	int UpdateInput();
	bool GetInputState2(int inp);
	bool GetKeyboardState(int inp);
	bool GetJoystickState(int inp);
	HRESULT CreateDeviceEx(REFGUID rguid);
	HRESULT SetJoystickProperty(REFGUID rguidProp, LPCDIPROPHEADER pdiph);
	HRESULT InitializeJoystick(REFGUID rguid);
	int ClearInput();
public:
	bool GetInputEvent(int inp)
	{
		return m_bPresentState[inp] && !m_bFormerState[inp];
	}
	bool GetInputHanasi(int inp)
	{
		return !m_bPresentState[inp] && m_bFormerState[inp];
	}
	bool GetKeyboardState(BYTE key);
	bool GetInputState(int inp)
	{
		return m_bPresentState[inp];
	}
	int GetLR()
	{
		return m_iLR;
	}
	int	GetUD()
	{
		return m_iUD;
	}
public:
	int InitSound();
	int InitMidi();
	int LoadMidi(char* lpszFileName, int num);
	int PlayMidi();
	int StopMidi();
	LPDIRECTSOUND GetDS()
	{
		return m_pDS;
	}
private:
	HWND m_hWnd;
	HINSTANCE m_hInst;
	HACCEL m_hAccel;
	bool m_bWindow;
	bool m_bDouble;
	bool m_bActive;
	int	m_time;
	RECT m_rcClient;
	RECT m_rcWindow;
	DWORD m_dwOldTime;
	DWORD m_dwFPS;
	DWORD m_dwCount;
private:
	LPDIRECTDRAW7 m_pDD;
	LPDIRECTDRAWSURFACE7 m_pddsPrimaryBuffer;
	LPDIRECTDRAWSURFACE7 m_pddsBackBuffer;
	LPDIRECTDRAWSURFACE7 m_pddsFPS;
	list<CNkImage*>	m_lstpImage;
	list<tagDRAWINFO> m_lstDInfo;
	LPDIRECTDRAWGAMMACONTROL m_pGammaControl;
	DDGAMMARAMP	m_gammaInit;
private:
	LPDIRECTINPUT8 m_pDI;
	LPDIRECTINPUTDEVICE8 m_pdidKeyboard;
	LPDIRECTINPUTDEVICE8 m_pdidJoystick;
	BYTE m_bKeyState[256];
	DIJOYSTATE2	m_diJoyState;
	bool m_bPresentState[INP_MAX];
	bool m_bFormerState[INP_MAX];
	int	m_iLR;
	int	m_iUD;
private:
	LPDIRECTSOUND m_pDS;
	IDirectMusicLoader*	m_pdml;
	IDirectMusicPerformance* m_pdmp;
	IDirectMusicSegment* m_pdms;
};

BOOL CALLBACK EnumObjectsCallback(const DIDEVICEOBJECTINSTANCE* pdidoi, VOID* pContext );
BOOL CALLBACK EnumJoysticksCallback2(const DIDEVICEINSTANCE* pdidInstance, VOID* pContext );
BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE* pdidInstance, VOID* pContext );


