#include "NkImage.h"

#include "png.h"

HBITMAP LoadPng(const string &strFilename);

CNkImage::CNkImage()
{
	m_pdds = NULL;
	m_szFileName[0] = NULL;
	g_pNkLib->AddList(this);
}

CNkImage::CNkImage(char* lpszFileName, int width, int height)
{
	m_pdds = NULL;
	Load(lpszFileName, width, height);
	g_pNkLib->AddList(this);
}

int CNkImage::Load(char* lpszFileName, int width, int height)
{
	SAFE_RELEASE(m_pdds);
	SAFE_DELETE(m_pdds);
	if (m_szFileName != lpszFileName)
	{
		strcpy(m_szFileName,lpszFileName);
	}
	LoadPNG(lpszFileName);
	if (width > 0)
	{
		m_width = width;
	}
	else
	{
		m_width = m_bmpWidth;
	}
	if (height > 0)
	{
		m_height = height;
	}
	else
	{
		m_height = m_bmpHeight;
	}
	return 1;
}

CNkImage::~CNkImage()
{
	SAFE_RELEASE(m_pdds);
	if (g_pNkLib)
	{
		g_pNkLib->RemoveList(this);
	}
}

void CNkImage::Release()
{
	SAFE_RELEASE(m_pdds);
}

int CNkImage::LoadBMP(char* lpszFileName)
{
	HBITMAP 	   hBMP = NULL;
	BITMAP		   bmp;
	DDSURFACEDESC2 ddsd;
	hBMP = (HBITMAP) LoadImage(GetModuleHandle(NULL), lpszFileName,
		IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION );
	if (hBMP == NULL)
	{
		hBMP = (HBITMAP) LoadImage( NULL, lpszFileName, 
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION );
		if (hBMP == NULL)
		{
			return 0;
		}
	}
	GetObject(hBMP, sizeof(bmp), &bmp);
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	if (g_pNkLib->GetDouble())
	{
		ddsd.dwWidth = bmp.bmWidth * 2;
		ddsd.dwHeight = bmp.bmHeight * 2;
	}
	else
	{
		ddsd.dwWidth = bmp.bmWidth;
		ddsd.dwHeight = bmp.bmHeight;
	}
	m_bmpWidth = (int)bmp.bmWidth;
	m_bmpHeight = (int)bmp.bmHeight;
	if (!g_pNkLib->CreateSurface(&ddsd, &m_pdds))
	{
		SAFE_RELEASE(m_pdds);
		return 0;
	}
	if (!DrawBitmap(hBMP))
	{
		DeleteObject(hBMP);
		return 0;
	}
	DeleteObject(hBMP);
	SetColorKey(RGB(255,0,255));
	return 1;
}

int CNkImage::LoadPNG(char* lpszFileName)
{
	HBITMAP hBMP = NULL;
	BITMAP bmp;
	DDSURFACEDESC2 ddsd;
	hBMP = LoadPng((string)lpszFileName);
	if (hBMP == NULL)
	{
		MB(lpszFileName);
		return 0;
	}
	GetObject(hBMP, sizeof(bmp), &bmp);
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
	ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
	ddsd.ddpfPixelFormat.dwSize = sizeof(ddsd.ddpfPixelFormat);
	ddsd.ddpfPixelFormat.dwFlags = DDPF_RGB;
	ddsd.ddpfPixelFormat.dwRGBBitCount = 16;
	ddsd.ddpfPixelFormat.dwRBitMask = 0x0000F800;
	ddsd.ddpfPixelFormat.dwGBitMask = 0x000007E0;
	ddsd.ddpfPixelFormat.dwBBitMask = 0x0000001F;
	ddsd.ddpfPixelFormat.dwRGBAlphaBitMask = 0x00000000;
	if(g_pNkLib->GetDouble())
	{
		ddsd.dwWidth = bmp.bmWidth * 2;
		ddsd.dwHeight = bmp.bmHeight * 2;
	}
	else
	{
		ddsd.dwWidth = bmp.bmWidth;
		ddsd.dwHeight = bmp.bmHeight;
	}
	m_bmpWidth = (int)bmp.bmWidth;
	m_bmpHeight = (int)bmp.bmHeight;
	if (!g_pNkLib->CreateSurface(&ddsd, &m_pdds))
	{
		SAFE_RELEASE(m_pdds);
		return 0;
	}
	if (!DrawBitmap(hBMP))
	{
		DeleteObject(hBMP);
		return 0;
	}
	DeleteObject(hBMP);
	SetColorKey(RGB(255,0,255));
	return 1;
}

int CNkImage::DrawBitmap(HBITMAP hBMP)
{
	HDC hDCImage;
	HDC hDC;
	BITMAP bmp;
	DDSURFACEDESC2 ddsd;
	if (hBMP == NULL || m_pdds == NULL)
	{
		return 0;
	}
	if (FAILED(m_pdds->Restore()))
	{
		return 0;
	}
	ddsd.dwSize = sizeof(ddsd);
	m_pdds->GetSurfaceDesc( &ddsd );
	if (ddsd.ddpfPixelFormat.dwFlags == DDPF_FOURCC)
	{
		return 0;
	}
	hDCImage = CreateCompatibleDC(NULL);
	if (NULL == hDCImage)
	{
		return 0;
	}
	SelectObject(hDCImage, hBMP);
	GetObject(hBMP, sizeof(bmp), &bmp);
	if (FAILED(m_pdds->GetDC(&hDC)))
	{
		return 0;
	}
	StretchBlt(hDC, 0, 0, ddsd.dwWidth, ddsd.dwHeight, 
		hDCImage, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
	if (FAILED(m_pdds->ReleaseDC(hDC)))
	{
		return 0;
	}
	DeleteDC(hDCImage);
	return 1;
}

int CNkImage::SetColorKey( DWORD dwColorKey )
{
	if (NULL == m_pdds)
	{
		return 0;
	}
	DDCOLORKEY ddck;
	ddck.dwColorSpaceLowValue = ConvertGDIColor(dwColorKey);
	ddck.dwColorSpaceHighValue = ConvertGDIColor(dwColorKey);
	if (FAILED(m_pdds->SetColorKey(DDCKEY_SRCBLT, &ddck)))
	{
		return 0;
	}
	return 1;
}

DWORD CNkImage::ConvertGDIColor( COLORREF dwGDIColor )
{
	if (m_pdds == NULL)
	{
		return 0x00000000;
	}
	COLORREF rgbT;
	HDC hdc;
	DWORD dw = CLR_INVALID;
	DDSURFACEDESC2 ddsd;
	HRESULT hr;
	if( dwGDIColor != CLR_INVALID && m_pdds->GetDC(&hdc) == DD_OK)
	{
		rgbT = GetPixel(hdc, 0, 0);
		SetPixel(hdc, 0, 0, dwGDIColor);
		m_pdds->ReleaseDC(hdc);
	}
	ddsd.dwSize = sizeof(ddsd);
	hr = m_pdds->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL);
	if (hr == DD_OK)
	{
		dw = *(DWORD *) ddsd.lpSurface; 
		if (ddsd.ddpfPixelFormat.dwRGBBitCount < 32 )
		{
			dw &= ( 1 << ddsd.ddpfPixelFormat.dwRGBBitCount ) - 1;	
		}
		m_pdds->Unlock(NULL);
	}
	if (dwGDIColor != CLR_INVALID && m_pdds->GetDC(&hdc) == DD_OK)
	{
		SetPixel(hdc, 0, 0, rgbT);
		m_pdds->ReleaseDC(hdc);
	}
	return dw;
}

int CNkImage::DrawLayer(int iDestX, int iDestY, int layer, RECT* prcSrc, bool trans)
{
	if (iDestX >= SCREEN_WIDTH || 
		iDestY >= SCREEN_HEIGHT || 
		iDestX + m_width <= 0 || 
		iDestY + m_height <= 0)
	{
		return 0;
	}
	DRAWINFO dInfo;
	dInfo.spr = layer;
	RECT rctSrc;
	if (prcSrc)
	{
		rctSrc = *prcSrc;
	}
	else
	{
		rctSrc.left = 0;
		rctSrc.top = 0;
		rctSrc.right = m_width;
		rctSrc.bottom = m_height;
	}
	dInfo.pDrawQue = new CDrawNormal(this, iDestX, iDestY, rctSrc, trans);
	g_pNkLib->AddDrawList(dInfo);
	return 1;
}

int CNkImage::DrawLayerStretch(LPRECT prcDest,LPRECT prcSrc,int layer,bool trans)
{
	//FIMXE:
	if (prcDest && 
		(prcDest->right <= 0) || 
		prcDest->bottom <= 0 || 
		prcDest->left >= SCREEN_WIDTH ||
		prcDest->top >= SCREEN_HEIGHT)
	{
		return 0;
	}
	DRAWINFO dInfo;
	dInfo.spr = layer;
	RECT rctSrc, rctDest;
	if (prcSrc)
	{
		rctSrc = *prcSrc;
	}
	else
	{
		rctSrc.left = 0;
		rctSrc.top = 0;
		rctSrc.right = m_width;
		rctSrc.bottom = m_height;
	}
	if (prcDest)
	{
		rctDest = *prcDest;
	}
	else
	{
		rctDest.left = 0;
		rctDest.top = 0;
		rctDest.right = m_width;
		rctDest.bottom = m_height;
	}
	dInfo.pDrawQue = new CDrawQueStretch(this, rctDest, rctSrc, trans);
	g_pNkLib->AddDrawList(dInfo);
	return 1;
}

int CNkImage::Fill(DWORD dwColor)
{
	DDBLTFX ddbltfx;
	ZeroMemory(&ddbltfx,sizeof ddbltfx);
	ddbltfx.dwSize = sizeof ddbltfx;
	ddbltfx.dwFillColor = dwColor;
	if (FAILED(m_pdds->Blt(NULL,NULL,NULL,DDBLT_COLORFILL,&ddbltfx)))
	{
		return 0;
	}
	return 1;
}

//#define MASK1	0xf79ef79e	// 1111011110011110 half mask
#define MASK2	0x07e0f81f	// 0000011111100000 (565)Gmask + RBmask
#define MASK3	0xf81f07e0	// 1111100000011111 (565)RBmask + Gmask
//#define MASK4	0x001f07e0	// 0000000000011111 (565)Bmask + Gmask
//#define MASK5	0xf8000000	// 1111100000000000 (565)Rmask + 0
#define MASK6	0x07e00000	// G1MASK
#define MASK7	0xf81f0000	// 1111100000011111
#define MASK8	0x000007e0
#define MASK9	0x0000f81f

#define R1MASK	0xf8000000
#define G1MASK	0x07e00000
#define B1MASK	0x001f0000
#define R2MASK	0x0000f800
#define G2MASK	0x000007e0
#define B2MASK	0x0000001f

#define OUTPUTCOLOR(a,b)/* Outputf("\n%s:R1=%u;G1=%u;B1=%u;R2=%u;G2=%u;B2=%u; \n",\
					b,\
					(a & R1MASK) / 0x08000000,\
					(a & G1MASK) / 0x00200000,\
					(a & B1MASK) / 0x00010000,\
					(a & R2MASK) / 0x00000800,\
					(a & G2MASK) / 0x00000020,\
					(a & B2MASK) / 0x00000001);*/

DWORD CCalAlpha::Get(DWORD dest,DWORD src)
{
	DWORD ret1= (src&MASK2)*m_alpha/ALPHA_MAX+(dest&MASK2)*m_beta/ALPHA_MAX;
	DWORD ret2= (src&MASK3)/ALPHA_MAX*m_alpha+(dest&MASK3)/ALPHA_MAX*m_beta;
	DWORD ret = ret1&MASK2 | ret2&MASK3;
	return ret;
}

DWORD CCalTransAlpha::Get(DWORD dest,DWORD src)
{
	if (src == COLORKEY1 || (src & _mask01) == COLORKEY3 || (src & _mask10) == COLORKEY2)
	{
		return dest;
	}
	else
	{
		DWORD ret1= (src&MASK2)*m_alpha/ALPHA_MAX+(dest&MASK2)*m_beta/ALPHA_MAX;
		DWORD ret2= (src&MASK3)/ALPHA_MAX*m_alpha+(dest&MASK3)/ALPHA_MAX*m_beta;
		return ret1&MASK2 | ret2&MASK3;
	}
}


#define for if (0) ; else for

void PngReadProc(png_structp png_ptr, png_bytep data, png_size_t length) 
{
	ReadFile(png_get_io_ptr(png_ptr), data, length, (DWORD*)&length, NULL);
}

void to4bpp(png_structp png_ptr, png_row_infop row_info, png_bytep data) 
{
	static const png_byte pix[] = {
		0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13,
		0x20, 0x21, 0x22, 0x23, 0x30, 0x31, 0x32, 0x33,
	};
	png_uint_32 rowb;
	png_byte *p, *q, c;
	rowb = (row_info->width + 1) / 2;
	q = data + rowb;
	p = data + rowb / 2;
	if (rowb % 2 == 1) 
	{
		c = *p;
		*(--q) = pix[c >> 4];
	}
	while (p > data) 
	{
		c = *(--p);
		*(--q) = pix[c & 0x0f];
		*(--q) = pix[c >> 4];
	}
	row_info->bit_depth = 4;
	row_info->pixel_depth = 4;
	row_info->rowbytes = rowb;
}

HBITMAP LoadPng(const string &strFilename) 
{
	HANDLE hFile = CreateFile(strFilename.c_str(), GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return NULL;
	}
	png_struct *png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png_ptr) 
	{
		CloseHandle(hFile);
		return NULL;
	}
	png_info *info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) 
	{
		png_destroy_read_struct(&png_ptr, NULL, NULL);
		CloseHandle(hFile);
		return NULL;
	}
	png_info *end_info = png_create_info_struct(png_ptr);
	if (!end_info) 
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		CloseHandle(hFile);
		return NULL;
	}
	png_set_read_fn(png_ptr, hFile, PngReadProc);
	png_uint_32 nWidth, nHeight;
	int nDepth, nPal;
	int nPngDepth, nColorType, nInterlaceType, nCompType, nFilterType;
	png_read_info(png_ptr, info_ptr);
	png_get_IHDR(png_ptr, info_ptr, &nWidth, &nHeight, &nPngDepth, &nColorType, &nInterlaceType, &nCompType, &nFilterType);
	if (nColorType == PNG_COLOR_TYPE_RGB || nColorType == PNG_COLOR_TYPE_RGB_ALPHA) 
	{
		nPngDepth = 24;
		nDepth = 24;
		nPal = 0;
	} 
	else 
	{
		switch (nPngDepth) 
		{
		case 2:  
			nDepth = 4; 
			break;
		  
		case 16: 
			nDepth = 8; 
			break;
		  
		default: 
			nDepth = nPngDepth; 
			break;
		}
		nPal = 1 << nDepth;
	}
	vector<png_color> vPalette;
	if (nPal > 0)
	{
		vPalette.resize(nPal);
	}
	int nRowBytes = (nWidth * nDepth + 31) / 32 * 4;
	int nImgBytes = nRowBytes * nHeight;
	BYTE *pImgPtr = (BYTE*)GlobalAlloc(GMEM_FIXED, nImgBytes);
	vector<BYTE*> vRowPtr;
	vRowPtr.reserve(nHeight);
	for (int y = nHeight - 1; y >= 0; --y)
	{
		vRowPtr.push_back(pImgPtr + y * nRowBytes);
	}
	if (nColorType & PNG_COLOR_MASK_ALPHA)
    {
		png_set_strip_alpha(png_ptr);
	}
	if (nPngDepth == 2)
	{
		png_set_read_user_transform_fn(png_ptr, to4bpp);
	}
	else if (nPngDepth == 16)
    {
		png_set_strip_16(png_ptr);
	}
	if (nColorType== PNG_COLOR_TYPE_RGB || nColorType == PNG_COLOR_TYPE_RGB_ALPHA)
    {
		png_set_bgr(png_ptr);
	}
	png_read_update_info(png_ptr, info_ptr);
	if (nPal > 0) 
	{
		if (nColorType == PNG_COLOR_TYPE_PALETTE) 
		{
			png_color *palette;
			int num_palette;
			png_get_PLTE(png_ptr, info_ptr, &palette, &num_palette);
			if (num_palette > nPal)
			{
				num_palette = nPal;
			}
			memset(vPalette.begin(), 0, nPal * sizeof png_color);
			memcpy(vPalette.begin(), palette, num_palette * sizeof png_color);
		} 
		else 
		{
			int depth = nPngDepth == 16 ? 8 : nPngDepth;
			png_build_grayscale_palette(depth, vPalette.begin());
		}
	}
	png_read_image(png_ptr, vRowPtr.begin());
	png_read_end(png_ptr, end_info);
	png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
	CloseHandle(hFile);
	BITMAPINFO* bi = (BITMAPINFO*)GlobalAlloc(GMEM_FIXED, sizeof BITMAPINFOHEADER + nPal * sizeof RGBQUAD);
	memset(bi, 0, sizeof BITMAPINFOHEADER);
	bi->bmiHeader.biSize = sizeof BITMAPINFOHEADER;
	bi->bmiHeader.biWidth = nWidth;
	bi->bmiHeader.biHeight = nHeight;
	bi->bmiHeader.biPlanes = 1;
	bi->bmiHeader.biBitCount = nDepth;
	bi->bmiHeader.biCompression = BI_RGB;
	bi->bmiHeader.biSizeImage = nImgBytes;
	bi->bmiHeader.biClrUsed = nPal;
	for (int i = 0; i < nPal; ++i) 
	{
		bi->bmiColors[i].rgbRed = vPalette[i].red;
		bi->bmiColors[i].rgbGreen = vPalette[i].green;
		bi->bmiColors[i].rgbBlue = vPalette[i].blue;
	}
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetDC(hwnd);
	char *pBits;
	HBITMAP hBitmap = CreateDIBSection(hdc, bi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	if (pBits)
	{
		memcpy(pBits, pImgPtr, nImgBytes);
	}
	ReleaseDC(hwnd, hdc);
	GlobalFree(pImgPtr);
	GlobalFree(bi);
	return hBitmap;
}
