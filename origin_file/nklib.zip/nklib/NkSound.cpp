#include "NkSound.h"
#include "NkLib.h"

#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

CNkSound::CNkSound()
{
	for (int i = 0; i < SOUNDBUFFER_NUM; ++i)
	{
		m_pdsb[i] = NULL;
	}
	m_pDS = g_pNkLib->GetDS();
	m_index=0;
}

CNkSound::CNkSound(char* lpszFileName)
{
	for(int i=0;i<SOUNDBUFFER_NUM;++i)
	{
		m_pdsb[i] = NULL;
	}
	m_pDS = g_pNkLib->GetDS();
	m_index=0;
	Load(lpszFileName);
}

CNkSound::~CNkSound()
{
	Release();
}

int CNkSound::Release()
{
	for (int i = 0; i < SOUNDBUFFER_NUM; ++i)
	{
		SAFE_RELEASE(m_pdsb[i]);
	}
	return 0;
}

int CNkSound::Play(DWORD dwFlags)
{
//	m_pdsb[m_index]->Stop();
	m_pdsb[m_index]->Play(0,0,dwFlags);
	m_index++;
	if(m_index == SOUNDBUFFER_NUM)
	{
		m_index = 0;
	}
	return 0;
}

int CNkSound::Stop()
{
	DWORD dwFlags;
	for (int i = 0; i < SOUNDBUFFER_NUM; ++i)
	{
		if (FAILED(m_pdsb[i]->GetStatus(&dwFlags)))
		{
			return 0;
		}
		else if(dwFlags & DSBSTATUS_PLAYING)
		{
			m_pdsb[i]->Stop();
		}
	}
	return 1;
}

int CNkSound::Load(char* lpszFileName)
{
	MMCKINFO oya_chunk, ko_chunk;
	HMMIO hmmio = mmioOpen(lpszFileName, NULL, MMIO_READ|MMIO_ALLOCBUF);
	if (!hmmio) 
	{
		return false;
	}
	oya_chunk.fccType = mmioFOURCC('W', 'A', 'V', 'E');
	if (mmioDescend(hmmio, &oya_chunk, NULL, MMIO_FINDRIFF) != MMSYSERR_NOERROR) 
	{
		mmioClose(hmmio, 0);
		return false;
	}
	ko_chunk.ckid = mmioFOURCC('f', 'm', 't', ' ');
	if (mmioDescend(hmmio, &ko_chunk, &oya_chunk, MMIO_FINDCHUNK) != MMSYSERR_NOERROR) 
	{
		mmioClose(hmmio, 0);
		return false;
	}
	WAVEFORMATEX wfex;
	if (mmioRead(hmmio, (HPSTR)&wfex, (LONG)ko_chunk.cksize) != (LONG)ko_chunk.cksize) 
	{
		mmioClose(hmmio, 0);
		return false;
	}
	mmioAscend(hmmio, &ko_chunk, 0);
	ko_chunk.ckid = mmioFOURCC('d', 'a', 't', 'a');
	if (mmioDescend(hmmio, &ko_chunk, &oya_chunk, MMIO_FINDCHUNK)) 
	{
		mmioClose(hmmio, 0);
		return false;
	}
	LPBYTE pdata = (LPBYTE)malloc(ko_chunk.cksize);
	if (mmioRead(hmmio, (HPSTR)pdata, (LONG)ko_chunk.cksize) != (LONG)ko_chunk.cksize)
	{
		free(pdata);
		mmioClose(hmmio, 0);
		return false;
	}
	mmioClose(hmmio, 0);
	DSBUFFERDESC dsbdesk;
	ZeroMemory(&dsbdesk, sizeof(DSBUFFERDESC));
	dsbdesk.dwSize = sizeof(DSBUFFERDESC);
	dsbdesk.dwFlags = DSBCAPS_CTRLPAN|DSBCAPS_CTRLVOLUME|DSBCAPS_GLOBALFOCUS ;
	dsbdesk.dwBufferBytes = ko_chunk.cksize;
	dsbdesk.lpwfxFormat = &wfex; 
	for (int i = 0; i < SOUNDBUFFER_NUM; i++)
	{
		if (FAILED(m_pDS->CreateSoundBuffer(&dsbdesk, &m_pdsb[i], NULL)))
		{		
			return false;
		}
		LPVOID pmem;
		DWORD size;
		m_pdsb[i]->Lock(0, ko_chunk.cksize, &pmem, &size, NULL, 0, 0);
		memcpy(pmem, pdata, size);
		m_pdsb[i]->Unlock(pmem, size, NULL, 0);
	}
	free(pdata);
	return true;
}

