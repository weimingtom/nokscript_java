// SunExeption.cpp: SunExeption ���饹�Υ���ץ���Ʃ`�����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SunExeption.h"
#include "SunLog.h"

//////////////////////////////////////////////////////////////////////
// ���B/����
//////////////////////////////////////////////////////////////////////

SunExeption::SunExeption(const char* fmt,...)
{
	char str[512];	//�Q�ᤦ����
	va_list arg;
	va_start(arg,fmt);
	vsprintf(str, fmt, arg);
	va_end(arg);

	m_str = str;
}

SunExeption::~SunExeption()
{

}

int SunExeption::operator ()()
{
	SunLog.LogOut(m_str.c_str());
	::MessageBox(NULL,m_str.c_str(),"����`",MB_OK | MB_ICONERROR);
	return 1;
}
