//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDI_MAIN_ICON                   101
#define IDI_MAIN                        101
#define IDR_MENU                        102
#define IDR_MAIN_ACCEL                  103
#define IDB_DIRECTX                     107
#define IDR_MENU1                       109
#define IDM_ABOUT                       1000
#define IDM_EXIT                        1001
#define IDM_SCREENMODE		            1002
#define IDM_TOGGLEFULLSCREEN            1003
#define IDM_DOUBLE                      40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
