#pragma once

CFunc* NewFunc(CBlock* pBlock,CTokenArray* pTokenArray,int first,int last);
CFunc* NewFunc2(CBlock* pBlock,CTokenArray* pTokenArray,int first,int& last);
