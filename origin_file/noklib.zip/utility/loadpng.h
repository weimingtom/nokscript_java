#ifndef _LOADPNG_H__
#define _LOADPNG_H__

//---------------------------------------------------------------------------
// PNG�t�@�C����ǂݍ���
HBITMAP LoadPng(const string &strFilename);

#endif //_LOADPNG_H__
